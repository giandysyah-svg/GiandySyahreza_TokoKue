CREATE DATABASE IF NOT EXISTS toko_kue CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE toko_kue;
CREATE TABLE IF NOT EXISTS admins (id INT AUTO_INCREMENT PRIMARY KEY, username VARCHAR(50) UNIQUE NOT NULL, password VARCHAR(255) NOT NULL, created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS menus (id INT AUTO_INCREMENT PRIMARY KEY, nama VARCHAR(150) NOT NULL, harga DECIMAL(12,2) NOT NULL DEFAULT 0, deskripsi TEXT, gambar VARCHAR(255), created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP, updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP);
INSERT INTO admins(username,password) VALUES('admin','$2y$12$OxRKLlccbj5XMe2pCorHfeuE7bsrFA4uj.8xvfeS1KcN9Htj9Pg66') ON DUPLICATE KEY UPDATE password=VALUES(password);
INSERT INTO menus(nama,harga,deskripsi,gambar) VALUES ('Brownies Cokelat',35000,'Brownies cokelat lembut dengan rasa manis yang pas.',NULL),('Cheesecake',45000,'Cheesecake creamy dengan tekstur lembut dan topping pilihan.',NULL),('Kue Tart',75000,'Kue tart cocok untuk berbagai acara dan perayaan.',NULL);
