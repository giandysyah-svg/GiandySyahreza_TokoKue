<?php
session_start(); require_once __DIR__.'/config.php';
$menus=$pdo->query('SELECT * FROM menus ORDER BY id DESC')->fetchAll();
function e($v){return htmlspecialchars($v??'',ENT_QUOTES,'UTF-8');}
?>
<!doctype html><html lang="id"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Toko Kue</title><link rel="stylesheet" href="assets/style.css?v=3"></head><body>
<header class="navbar"><div class="brand">🍰 Toko Kue</div><a href="admin/login.php" class="btn btn-outline">Login Admin</a></header>
<section class="hero"><div class="hero-inner"><div><span class="eyebrow">Fresh • Homemade • Modern</span><h1>Manisnya momen,<br><b>lezatnya pilihan.</b></h1><p>Nikmati pilihan kue dan dessert pilihan kami dengan tampilan modern dan rasa yang dibuat dengan sepenuh hati.</p></div></section>
<main class="container"><div class="section-head"><div><span class="eyebrow">MENU</span><h2>Daftar Menu</h2></div></div><div class="grid">
<?php foreach($menus as $m): ?><article class="card"><div class="card-media"><?php if($m['gambar']): ?><img src="uploads/<?=e($m['gambar'])?>" alt="<?=e($m['nama'])?>"><?php else: ?><div class="placeholder">🍰</div><?php endif; ?></div><div class="card-body"><h3><?=e($m['nama'])?></h3><p><?=nl2br(e($m['deskripsi']))?></p><strong class="price">Rp <?=number_format($m['harga'],0,',','.')?></strong></div></article><?php endforeach; ?>
<?php if(!$menus): ?><div class="empty">Belum ada menu. Silakan login sebagai admin untuk menambahkan menu.</div><?php endif; ?></div></main><footer>© <?=date('Y')?> Toko Kue</footer></body></html>
