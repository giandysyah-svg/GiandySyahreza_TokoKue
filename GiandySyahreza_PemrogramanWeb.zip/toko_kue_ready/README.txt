TOKO KUE - PHP MYSQL

CARA MENJALANKAN DI XAMPP:
1. Ekstrak folder toko_kue_ready ke C:\xampp\htdocs\ dan rename menjadi toko_kue jika diinginkan.
2. Jalankan Apache dan MySQL dari XAMPP.
3. Buka http://localhost/phpmyadmin
4. Import file sql/database.sql.
5. Buka http://localhost/toko_kue_ready/
6. Login admin: username admin, password password

Jika database sudah pernah diimport sebelumnya, import ulang sql/database.sql agar password admin diperbarui.

FITUR:
- Tampilan coklat muda + putih modern dan responsif
- Login admin berbasis session
- Tambah, edit, hapus menu
- Nama, harga, deskripsi, foto menu
- Validasi upload gambar
- Database MySQL
